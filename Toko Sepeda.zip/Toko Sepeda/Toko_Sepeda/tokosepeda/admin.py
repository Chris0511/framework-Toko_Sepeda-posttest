from django.contrib import admin
from .models import Category, Customer, Order, OrderItem, Product, Invoice

class InvoiceInline(admin.StackedInline):
    model = Invoice
    fields = ('total_amount', 'status', 'notes')
    extra = 1  

class OrderAdmin(admin.ModelAdmin):
    inlines = [InvoiceInline]
    list_display = ('id', 'customer', 'order_date', 'total_amount', 'status')

    def save_related(self, request, form, formsets, change):
        super().save_related(request, form, formsets, change)
        
        for formset in formsets:
            if formset.model == Invoice:
                for instance in formset.save_existing_objects():
                    if not instance.pk:
                        instance.total_amount = form.instance.total_amount
                    instance.save()

# Register models
admin.site.register(Category)
admin.site.register(Customer)
admin.site.register(Product)
admin.site.register(Order, OrderAdmin)
admin.site.register(OrderItem)